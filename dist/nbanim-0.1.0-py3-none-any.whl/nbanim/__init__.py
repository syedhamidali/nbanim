from .core import NBAnim
__version__ = 0.1.0
